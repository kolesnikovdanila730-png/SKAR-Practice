package com.skar.modmenu

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.widget.*

class MainActivity : Activity() {
    private val red = Color.rgb(239, 51, 64)
    private val bg = Color.rgb(12, 12, 16)
    private val panel = Color.rgb(25, 25, 33)
    private lateinit var body: LinearLayout
    private lateinit var navHome: TextView
    private lateinit var navSettings: TextView
    private lateinit var navAbout: TextView
    private val switches = mutableListOf<Switch>()
    private val sliders = mutableListOf<SeekBar>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(24), dp(20), dp(18))
        }
        val logo = TextView(this).apply {
            text = "SKAR  MOD MENU"
            textSize = 27f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        header.addView(logo, matchWrap())
        header.addView(TextView(this).apply {
            text = "PRO EDITION  •  ANDROID DEMO"
            textSize = 10f
            letterSpacing = 1.5f
            setTextColor(red)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), 0, dp(12), dp(12))
        }
        navHome = navButton("ГЛАВНАЯ")
        navSettings = navButton("НАСТРОЙКИ")
        navAbout = navButton("О ПРОЕКТЕ")
        listOf(navHome, navSettings, navAbout).forEach { v ->
            nav.addView(v, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        root.addView(nav)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)

        navHome.setOnClickListener { showTab(0) }
        navSettings.setOnClickListener { showTab(1) }
        navAbout.setOnClickListener { showTab(2) }
        showTab(0)
    }

    private fun showTab(tab: Int) {
        listOf(navHome, navSettings, navAbout).forEachIndexed { i, v ->
            v.setBackgroundColor(if (i == tab) red else panel)
            v.setTextColor(Color.WHITE)
        }
        body.removeAllViews()
        when (tab) {
            0 -> home()
            1 -> settings()
            else -> about()
        }
        val anim = AlphaAnimation(0f, 1f).apply { duration = 220 }
        body.startAnimation(anim)
    }

    private fun home() {
        card(body) {
            addView(section("ПАНЕЛЬ ТРЕНИРОВКИ"))
            addView(TextView(this@MainActivity).apply {
                text = "Добро пожаловать в SKAR"
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            })
            addView(label("Локальный интерфейс для настройки тренировочных привычек."))
            addSpace(this, 12)
            addView(label("СТАТУС: ДЕМО-РЕЖИМ", red))
        }
        card(body) {
            addView(section("ФУНКЦИИ"))
            switches.clear()
            val active = TextView(this@MainActivity).apply {
                text = "Активно: 0"
                textSize = 12f
                setTextColor(Color.LTGRAY)
            }
            addView(active)
            listOf(
                "Aim Assist — подсказка для тренировки",
                "Тренировочный прицел — визуальный макет",
                "Тренировочный бот — локальная памятка",
                "Скин-превью — просмотр концепта"
            ).forEach { name ->
                val sw = Switch(this@MainActivity).apply {
                    text = name
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    buttonTintList = tint()
                    setPadding(0, dp(7), 0, dp(7))
                    setOnCheckedChangeListener { _, _ ->
                        active.text = "Активно: ${switches.count { it.isChecked }}"
                    }
                }
                switches.add(sw)
                addView(sw, matchWrap())
            }
        }
        card(body) {
            addView(section("БЫСТРЫЕ ДЕЙСТВИЯ"))
            addView(actionButton("СБРОСИТЬ ВСЁ") {
                switches.forEach { it.isChecked = false }
                sliders.forEachIndexed { i, s -> s.progress = if (i == 0) 50 else 40 }
            })
            addView(label("Переключатели меняют только состояние этого приложения."))
        }
    }

    private fun settings() {
        card(body) {
            addView(section("НАСТРОЙКИ ТРЕНИРОВКИ"))
            sliders.clear()
            addSlider(this, "Чувствительность", 50)
            addSlider(this, "Размер маркера", 40)
            addSlider(this, "Скорость упражнения", 60)
        }
        card(body) {
            addView(section("ВНЕШНИЙ ВИД"))
            addView(label("Тема: чёрно-красная"))
            addView(label("Версия интерфейса: 2.0 PRO"))
            addView(label("Анимация переходов: включена"))
        }
    }

    private fun about() {
        card(body) {
            addView(section("О SKAR MOD MENU"))
            addView(TextView(this@MainActivity).apply {
                text = "SKAR"
                textSize = 34f
                typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                setTextColor(red)
            })
            addView(label("Фанатский Android-макет с вкладками, анимацией и локальными тренировочными настройками."))
            addSpace(this, 12)
            addView(label("ВАЖНО: приложение не подключается к Brawl Stars, не меняет игровой клиент, не выдаёт игровые преимущества и не взаимодействует с аккаунтом Supercell."))
        }
        card(body) {
            addView(section("ИНФОРМАЦИЯ"))
            addView(label("Версия: 2.0"))
            addView(label("Платформа: Android 6.0 и новее"))
            addView(label("Пакет: com.skar.modmenu"))
            addView(label("Неофициальный проект. Не связан с Supercell."))
        }
    }

    private fun addSlider(parent: LinearLayout, title: String, initial: Int) {
        val value = TextView(this).apply {
            text = "$title: $initial%"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
        }
        parent.addView(value)
        val seek = SeekBar(this).apply {
            max = 100
            progress = initial
            progressTintList = tint()
            thumbTintList = tint()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    value.text = "$title: $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sliders.add(seek)
        parent.addView(seek, matchWrap())
    }

    private fun card(parent: LinearLayout, build: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
            build()
        }
        val lp = matchWrap().apply { setMargins(0, 0, 0, dp(12)) }
        parent.addView(box, lp)
    }

    private fun navButton(text: String) = TextView(this).apply {
        this.text = text
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(3), 0, dp(3), 0)
        setBackgroundColor(panel)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        letterSpacing = 1.1f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(red)
        setPadding(0, 0, 0, dp(12))
    }

    private fun label(text: String, color: Int = Color.LTGRAY) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(color)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        backgroundTintList = tint()
        setOnClickListener { action() }
    }

    private fun tint() = android.content.res.ColorStateList.valueOf(red)
    private fun addSpace(parent: LinearLayout, h: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
