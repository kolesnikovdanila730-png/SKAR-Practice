package com.skar.practice

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.FrameLayout
import android.view.ViewGroup
import kotlin.random.Random

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("skar_practice", MODE_PRIVATE) }
    private lateinit var scoreText: TextView
    private lateinit var bestText: TextView
    private lateinit var timeText: TextView
    private lateinit var arena: TargetArena
    private var score = 0
    private var secondsLeft = 30
    private var timer: CountDownTimer? = null
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 13, 17)
        window.navigationBarColor = Color.rgb(13, 13, 17)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(Color.rgb(13, 13, 17))
        }
        val title = TextView(this).apply {
            text = "SKAR PRACTICE"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "ТРЕНАЖЁР РЕАКЦИИ • НЕ ВЛИЯЕТ НА BRAWL STARS"
            textSize = 10f
            setTextColor(Color.rgb(239, 90, 100))
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(18))
        }
        root.addView(subtitle, matchWrap())

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        scoreText = stat("СЧЁТ", "0")
        timeText = stat("ВРЕМЯ", "30")
        bestText = stat("РЕКОРД", prefs.getInt("best", 0).toString())
        stats.addView(scoreText, LinearLayout.LayoutParams(0, dp(62), 1f))
        stats.addView(timeText, LinearLayout.LayoutParams(0, dp(62), 1f))
        stats.addView(bestText, LinearLayout.LayoutParams(0, dp(62), 1f))
        root.addView(stats, matchWrap())

        arena = TargetArena().apply {
            onHit = {
                if (running) {
                    score++
                    scoreText.text = "СЧЁТ\n$score"
                    spawn()
                }
            }
        }
        val arenaFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(25, 25, 33))
            addView(arena, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        root.addView(arenaFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { setMargins(0, dp(14), 0, dp(14)) })

        val start = Button(this).apply {
            text = "НАЧАТЬ ТРЕНИРОВКУ"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(220, 45, 57)))
            setOnClickListener { startRound() }
        }
        root.addView(start, matchWrap())

        val hint = TextView(this).apply {
            text = "Нажимай на красную цель как можно быстрее за 30 секунд."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(hint, matchWrap())
        setContentView(root)
        arena.spawn()
    }

    private fun startRound() {
        timer?.cancel()
        score = 0
        secondsLeft = 30
        running = true
        scoreText.text = "СЧЁТ\n0"
        timeText.text = "ВРЕМЯ\n30"
        arena.spawn()
        timer = object : CountDownTimer(30_000, 1_000) {
            override fun onTick(ms: Long) {
                secondsLeft = (ms / 1000).toInt()
                timeText.text = "ВРЕМЯ\n$secondsLeft"
            }
            override fun onFinish() {
                running = false
                timeText.text = "ВРЕМЯ\n0"
                val best = maxOf(score, prefs.getInt("best", 0))
                prefs.edit().putInt("best", best).apply()
                bestText.text = "РЕКОРД\n$best"
                arena.clearTarget()
            }
        }.start()
    }

    private fun stat(label: String, value: String) = TextView(this).apply {
        text = "$label\n$value"
        textSize = 14f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(29, 29, 38))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    inner class TargetArena : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var targetX = 0f
        private var targetY = 0f
        private var radius = dp(28).toFloat()
        private var hasTarget = false
        var onHit: (() -> Unit)? = null

        fun spawn() {
            if (width <= 0 || height <= 0) {
                post { spawn() }
                return
            }
            radius = dp(22 + Random.nextInt(0, 15)).toFloat()
            targetX = radius + Random.nextFloat() * (width - radius * 2).coerceAtLeast(1f)
            targetY = radius + Random.nextFloat() * (height - radius * 2).coerceAtLeast(1f)
            hasTarget = true
            invalidate()
        }

        fun clearTarget() {
            hasTarget = false
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(Color.rgb(25, 25, 33))
            if (hasTarget) {
                paint.color = Color.rgb(239, 51, 64)
                canvas.drawCircle(targetX, targetY, radius, paint)
                paint.color = Color.WHITE
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(3).toFloat()
                canvas.drawCircle(targetX, targetY, radius * .58f, paint)
                paint.style = Paint.Style.FILL
            } else {
                paint.color = Color.LTGRAY
                paint.textSize = dp(14).toFloat()
                paint.textAlign = Paint.Align.CENTER
                canvas.drawText("Нажми «Начать тренировку»", width / 2f, height / 2f, paint)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_DOWN && hasTarget && running) {
                val dx = event.x - targetX
                val dy = event.y - targetY
                if (dx * dx + dy * dy <= radius * radius) {
                    onHit?.invoke()
                }
                return true
            }
            return true
        }
    }
}
