SKAR Practice — Android app project

Это безопасный самостоятельный тренажёр реакции:
- 30-секундный раунд на попадание по появляющейся цели.
- Счёт, таймер и сохранение лучшего результата на устройстве.
- Не подключается к Brawl Stars, не меняет игровой клиент и не даёт игровых преимуществ.

Сборка APK:
1. Установи Android Studio на компьютер.
2. Открой папку SKAR_Brawl_Practice_Android в Android Studio.
3. Дождись синхронизации Gradle.
4. Нужны JDK 17 и Android SDK 35.
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Файл будет в app/build/outputs/apk/debug/app-debug.apk.

Минимальная версия: Android 6.0 (API 23).
