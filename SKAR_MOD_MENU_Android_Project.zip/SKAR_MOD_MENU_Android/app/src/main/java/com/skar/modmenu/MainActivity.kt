package com.skar.modmenu

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val red = Color.rgb(239, 51, 64)
    private val bg = Color.rgb(13, 13, 17)
    private val panel = Color.rgb(27, 27, 35)
    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(content)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "SKAR MOD MENU"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "ANDROID • TRAINING DEMO"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(20))
        }
        content.addView(subtitle)

        val warning = TextView(this).apply {
            text = "ДЕМО-ПРИЛОЖЕНИЕ. Переключатели работают только внутри этой программы и не меняют Brawl Stars. Здесь нет внедрения в игру, обхода защиты или доступа к аккаунту."
            textSize = 13f
            setTextColor(Color.rgb(255, 205, 208))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(48, 20, 25))
        }
        content.addView(warning, matchWrap())
        addSpace(content, 16)

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        content.addView(card, matchWrap())
        card.addView(sectionTitle("ТРЕНИРОВОЧНЫЕ НАСТРОЙКИ"))
        count = TextView(this).apply {
            text = "Активных функций: 0"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        }
        card.addView(count)

        val switches = mutableListOf<Switch>()
        listOf(
            "Aim Assist — подсказка для тренировки",
            "Тренировочный прицел — визуальный макет",
            "Тренировочный бот — локальная памятка",
            "Скин-превью — без изменения игры"
        ).forEach { label ->
            val sw = Switch(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(red)
                setPadding(0, dp(9), 0, dp(9))
            }
            sw.setOnCheckedChangeListener { _, _ ->
                count.text = "Активных функций: ${switches.count { it.isChecked }}"
            }
            switches.add(sw)
            card.addView(sw, matchWrap())
        }

        addSpace(content, 14)
        val sliders = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        content.addView(sliders, matchWrap())
        sliders.addView(sectionTitle("НАСТРОЙКИ ТРЕНИРОВКИ"))
        addSeek(sliders, "Чувствительность", 50)
        addSeek(sliders, "Размер маркера", 40)

        val reset = Button(this).apply {
            text = "СБРОСИТЬ НАСТРОЙКИ"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(red))
            setOnClickListener {
                switches.forEach { it.isChecked = false }
                count.text = "Активных функций: 0"
                val seeks = sliders.tag as? List<SeekBar> ?: emptyList()
                seeks.getOrNull(0)?.progress = 50
                seeks.getOrNull(1)?.progress = 40
            }
        }
        content.addView(reset, matchWrap())
        val footer = TextView(this).apply {
            text = "SKAR • ФАНАТСКИЙ НЕОФИЦИАЛЬНЫЙ МАКЕТ"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
            setPadding(0, dp(18), 0, 0)
        }
        content.addView(footer)
    }

    private fun addSeek(parent: LinearLayout, label: String, initial: Int) {
        val value = TextView(this).apply {
            text = "$label: $initial%"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(0, dp(12), 0, 0)
        }
        parent.addView(value)
        val seek = SeekBar(this).apply {
            max = 100
            progress = initial
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    value.text = "$label: $p%"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(seek, matchWrap())
        val current = (parent.tag as? MutableList<SeekBar>) ?: mutableListOf()
        current.add(seek)
        parent.tag = current
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(red)
        setPadding(0, 0, 0, dp(10))
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(android.view.View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
