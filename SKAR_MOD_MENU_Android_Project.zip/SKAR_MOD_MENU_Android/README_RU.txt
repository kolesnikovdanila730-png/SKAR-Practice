SKAR MOD MENU — Android demo project

Что это:
- Отдельное Android-приложение с чёрно-красным интерфейсом.
- Локальные переключатели демонстрационных режимов.
- Два ползунка и кнопка сброса.
- Не подключается к Brawl Stars и не меняет игру.

Как собрать APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив.
3. В Android Studio выбери Open и укажи папку SKAR_MOD_MENU_Android.
4. Дождись синхронизации Gradle.
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. APK появится в app/build/outputs/apk/debug/.

Требования:
- Android Studio с Android SDK 35.
- JDK 17 (обычно поставляется с Android Studio).

Это исходный проект, а не готовый APK. Для сборки нужен Android Studio/SDK.
