package com.skar.practice

import android.app.Activity
import android.os.Bundle
import android.os.CountDownTimer
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var scoreText: TextView
    private lateinit var timeText: TextView
    private var score = 0
    private var best = 0
    private var running = false
    private var timer: CountDownTimer? = null
    private var target: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(28, 28, 28, 28)
        setBackgroundColor(Color.rgb(15, 18, 28))
    }

    private fun label(value: String, size: Float): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER; setPadding(8, 14, 8, 14)
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        setOnClickListener { action() }
    }

    private fun showHome() {
        val page = base()
        page.addView(label("SKAR PRACTICE", 28f))
        page.addView(label("Тренажёр реакции и точности\nНе взаимодействует с Brawl Stars", 16f))
        page.addView(button("НАЧАТЬ ТРЕНИРОВКУ") { startGame() })
        page.addView(label("Лучший результат: $best", 16f))
        page.addView(label("Нажимай на появляющиеся цели за 30 секунд.", 14f))
        setContentView(page)
    }

    private fun startGame() {
        score = 0
        running = true
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(15, 18, 28)) }
        val hud = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(27, 32, 48))
            gravity = Gravity.CENTER
        }
        scoreText = label("Очки: 0", 18f)
        timeText = label("Время: 30", 18f)
        hud.addView(scoreText, LinearLayout.LayoutParams(0, 64, 1f))
        hud.addView(timeText, LinearLayout.LayoutParams(0, 64, 1f))
        root.addView(hud, FrameLayout.LayoutParams(-1, 64, Gravity.TOP))
        setContentView(root)
        spawnTarget()
        timer = object : CountDownTimer(30000, 1000) {
            override fun onTick(ms: Long) { timeText.text = "Время: ${ms / 1000}" }
            override fun onFinish() { running = false; target?.visibility = View.GONE; showResult() }
        }.start()
    }

    private fun spawnTarget() {
        if (!running) return
        target?.let { root.removeView(it) }
        val size = (76 * resources.displayMetrics.density).toInt()
        val b = Button(this).apply {
            text = "●"; textSize = 24f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(90, 75, 220)))
            setOnClickListener {
                if (running) {
                    score++
                    scoreText.text = "Очки: $score"
                    spawnTarget()
                }
            }
        }
        target = b
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val x = Random.nextInt(0, (w - size).coerceAtLeast(1))
        val y = Random.nextInt((100 * resources.displayMetrics.density).toInt(),
            (h - size - 100).coerceAtLeast((100 * resources.displayMetrics.density).toInt() + 1))
        root.addView(b, FrameLayout.LayoutParams(size, size).apply {
            leftMargin = x; topMargin = y
        })
    }

    private fun showResult() {
        best = maxOf(best, score)
        val page = base()
        page.addView(label("ТРЕНИРОВКА ЗАВЕРШЕНА", 24f))
        page.addView(label("Твой результат: $score\nРекорд: $best", 20f))
        page.addView(button("ЕЩЁ РАЗ") { startGame() })
        page.addView(button("ГЛАВНОЕ МЕНЮ") { showHome() })
        setContentView(page)
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}
